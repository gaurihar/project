reg={'eax':"reg#32#1",'ecx':"reg#32#2",'edx':"reg#32#3",'ebx':"reg#32#1","ax":"reg#16#1",'cx':"reg#16#2",'dx':"reg#16#3",'bx':"reg#16#1",
      "al":"regL#8#1",'cl':"regL#8#2",'dl':"regL#8#3",'bl':"regL#8#1","ah":"regH#8#1",'ch':"regH#8#2",'dh':"regH#8#3",'bh':"regH#8#1"}
ins={'mov':"ins#1","add":"inst#13","dec":"inst#14","esp":"inst#15","cmp":"inst#16","jl":"inst#17","mul":"inst#18",'mvn':"inst#2",'push':"inst#3",'push':"inst#4",'jmp':"inst#5",'jz':"inst#6",'jnz':"inst#7",'je':"inst#8",'jne':"inst#9",'jgt':"inst#10","call":"inst#11","xor":"inst#12"}
